"""
A reference script for using the Process Mapper library for active classification.

For the paths to be right:
On command line, from grandparent (../..) run
python3 -m processMapper.scripts_examples.classificationExample
"""

import numpy as np
import matplotlib.pyplot as plt
import skimage as ski

#
from processMapper.dataSet import *
from processMapper.gaussClassifier import *
from processMapper.gaussRegression import *
from processMapper.activeLearningOptimizer import *

"""
Classification of Porous Ceramic samples
"""

dim = 2
computeNext = False # Do we want to compute next points?

## Import and prepare database

data = PCDataSet('./processMapper/samples_examples/initial_samples.csv') # Initialize dataSet
data.addFromCsv('./processMapper/samples_examples/samples_50.csv')       # Update dataSet
data.addFromCsv('./processMapper/samples_examples/fictive0.csv')         # Update dataSet a bit more

params = PreparationParameters()
#params.outputPermea = False
#params.outputFracture = False
params.inputDim = dim
params.sumporogens = True

data.prepareClassification(params)

## Perform classifcation

paramsC = gaussClassifierParams()
#paramsC.pseudoinf = 10
paramsR = gaussRegressionParams()
paramsR.anisotropy = True
paramsR.minAnisotropyRatio = 0
paramsR.corrlen = .1
paramsR.kernelT = "exponential"
paramsR.kernelI = "gaussian"

# Generate query points for mapping
nx = 101
ny = nx
nz = nx
xlist = np.linspace(0,1,nx)
ylist = np.linspace(0,1,ny)
if dim == 2:
   x0,y0 = np.meshgrid( xlist, ylist )
   x = x0.reshape((nx*ny,1))
   y = y0.reshape((nx*ny,1))
   query = np.concatenate( (x,y), axis=1 )
   
elif dim == 3:
   zlist = np.linspace(0,1,nz)
   x0,y0,z0 = np.meshgrid( xlist, ylist, zlist )
   x = x0.reshape((nx*ny*nz,1))
   y = y0.reshape((nx*ny*nz,1))
   z = z0.reshape((nx*ny*nz,1))
   query = np.concatenate( (x,y,z), axis=1 )

# Actually do some Gaussian Process Stuff
data.initializeClassification( paramsC, paramsR )
data.optimizeLogMLClassif( paramsC, paramsR )
data.classify( query, classifier=data.classifier )
# TODO: clean code

# Some displays
CovM  = data.classifier.regression.computeCovariance( data, data.classifier.regression.params )
logML = data.classifier.regression.computeLogML( data, data.classifier.regression.params, CovM )
print( "Maximal LogML measure Std: " + str(data.classifier.regression.params.stdM) )
print( "Maximal LogML correlation Lengths: " + str(data.classifier.regression.params.corrlenVect) )
print( "Maximal LogML: " + str(logML) )

# Compute next points
if computeNext:
   paramsA = learnOptParams()
   paramsA.npts = 10 # Number of points you want the algo to ask.
   #paramsA.niter = 200
   #paramsA.ponderation = 1.
   paramsA.useRegsKer = False # Use regression kernel in optim.

   ALOpt = learningOptimizer( data.classifier.regression, data, params=paramsA ) # Active Learning Optimizer
   ALOpt.optimBestCF()
   samples = ALOpt.preferredSamples
   print( "Next points: " + str(samples) )
   print( "Associated contribution to Composite Cost function: " + str(ALOpt.contrib2CF) )

if True: # Plot regression output.
   if dim == 2:
      toplot = np.reshape(data.classifier.classOutput, (nx,ny))
      fig=plt.figure()
      c=plt.pcolor( xlist, ylist, toplot, shading='nearest' )
      fig.colorbar(c)
      plt.contour( xlist, ylist, toplot, [.5], colors='k' )
      if computeNext:
         plt.scatter(samples[:,0],samples[:,1],marker='*',c='white')
      data.plot( figName=fig, show=True )
      
      """
      # Plot standard deviation
      toplot = np.reshape(data.classifier.regression.regsOutputStd2, (nx,ny))
      fig=plt.figure()
      c=plt.pcolor( xlist, ylist, toplot, shading='nearest' )
      fig.colorbar(c)
      data.plot( figName=fig, show=True )
      """
      
   elif dim == 3:
      toplot = np.reshape(data.classifier.classOutput, (nx,ny,nz))
      
      fig = plt.figure()
      ax = fig.add_subplot( 111, projection='3d' )
      if (max(toplot.flatten())-.5) * (min(toplot.flatten())-.5) <= 0: # If no sign change: problem
         verts, faces, _, _ = ski.measure.marching_cubes( toplot, .5 )#, spacing=(0.1, 0.1, 0.1) )
         ax.plot_trisurf( verts[:,0]/(nx-1), verts[:,1]/(ny-1), faces, verts[:,2]/(nz-1)) # Remark: `marching_cubes` gives coordinates in range [0,nx[; [0,ny[; [0,nz[. TODO: be sure of the (-1)
         
      ax.scatter(samples[:,0],samples[:,1],samples[:,3],marker='*',c='black')
      data.plot( figName=fig, show=True, subPlot=ax )
     
      # Behind: an implementation with pyvista (pv), which is more sexy, but doesn't mix well with matplotlib (at least for me)
   #   grid = pv.StructuredGrid( x0, y0, z0 )
   #   toplot = data.classifier.classOutput.flatten() #np.reshape(data.classifier.classOutput, (nx,ny,nz))
   #   grid["nimp"] = toplot # Note: "nimp" can be replaced by anything
   #   contours = grid.contour([0.5])

   #   p = pv.Plotter()
   #   p.add_mesh( contours, opacity=0.25, show_scalar_bar=False ) #, scalars=contours.points[:, 2])
   #   p.show()

