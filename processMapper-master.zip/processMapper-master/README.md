processMapper is a python toolkit dedicated the the building of behavior models for industrial processes.

See scripts_examples
